# Password Generator

## Overview

A simple web-based password generator.

## Features

- Customizable password length.
- Includes letters, digits, and punctuation.

## Technologies Used

- HTML
- JavaScript

## How to Run

1. Open password_generator.html in a web browser.

2. Enter the desired password length and click "Generate Password".